using UnityEngine;

// This class has one responsibility: find the precise 3D point the player is aiming at.
public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly Transform _playerTransform;
    private readonly float _maxRayDistance = 100f;
    private readonly int _aimLayerMask;

    // P_Cel: The 3D point in the world the crosshair is pointing at.
    public Vector3 AimPosition { get; private set; }

    public PlayerAiming(Camera cam, Transform playerTransform)
    {
        _cam = cam;
        _playerTransform = playerTransform;
        _aimLayerMask = ~LayerMask.GetMask("Player"); // Ignore the player layer

        // Initialize with a fallback value in front of the player
        AimPosition = _playerTransform.position + _playerTransform.forward * 10f;
    }

    public void Tick()
    {
        // 1. Create a Ray from the camera, passing through the mouse cursor's position.
        Ray ray = _cam.ScreenPointToRay(Input.mousePosition);

        // 2. Find the Hit Point (P_Cel).
        // We cast this ray into the 3D scene to see what it hits.
        if (Physics.Raycast(ray, out RaycastHit hit, _maxRayDistance, _aimLayerMask))
        {
            AimPosition = hit.point;
        }
        else
        {
            // Fallback: If the ray hits nothing (e.g., aiming at the sky),
            // we project it onto a virtual horizontal plane at the player's height.
            Plane groundPlane = new(Vector3.up, _playerTransform.position);
            if (groundPlane.Raycast(ray, out float enter))
            {
                AimPosition = ray.GetPoint(enter);
            }
        }
    }
}
