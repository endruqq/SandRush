using UnityEngine;

// This is the final, definitive aiming script.
// It uses a mathematical plane positioned at the player's feet to find the aiming point.
// This method is simple, fast, and completely independent of any physics colliders or layers.
public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly Transform _playerTransform;

    public Vector3 AimPosition { get; private set; }

    public PlayerAiming(Camera cam, Transform playerTransform)
    {
        _cam = cam;
        _playerTransform = playerTransform;

        // Initialize with a fallback value.
        AimPosition = _playerTransform.position + _playerTransform.forward * 5f;
    }

    public void Tick()
    {
        // 1. Create an infinite mathematical plane at the player's y-position.
        var groundPlane = new Plane(Vector3.up, new Vector3(0, _playerTransform.position.y, 0));

        // 2. Create a ray from the camera through the mouse cursor.
        var ray = _cam.ScreenPointToRay(Input.mousePosition);

        // 3. Find the intersection point.
        if (groundPlane.Raycast(ray, out var enter))
        {
            AimPosition = ray.GetPoint(enter);
        }
    }
}
