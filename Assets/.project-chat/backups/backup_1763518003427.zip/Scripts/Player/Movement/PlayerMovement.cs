using UnityEngine;

public class PlayerMovement
{
    private readonly float _accelerationTime;
    private readonly CharacterController _controller;

    // --- State ---
    private Vector3 _currentMoveVelocity;
    private Vector3 _velocityDamper;

    // --- Public State ---
    // (Dash logic removed for clarity, can be re-added if needed)
    public bool JustDashed { get; private set; } 

    public PlayerMovement(CharacterController controller, float accelerationTime)
    {
        _controller = controller;
        _accelerationTime = accelerationTime;
    }

    // Tick now takes all necessary inputs to calculate cursor-relative movement
    public void Tick(float moveSpeed, float horizontalInput, float verticalInput, Vector3 aimForwardDirection)
    {
        // 1. Calculate the "right" direction, perpendicular to the aiming direction.
        Vector3 aimRightDirection = new Vector3(aimForwardDirection.z, 0, -aimForwardDirection.x);

        // 2. Combine inputs with cursor-relative directions.
        // W/S moves along the aim line, A/D moves perpendicular to it.
        Vector3 targetDirection = (aimForwardDirection * verticalInput + aimRightDirection * horizontalInput).normalized;

        // 3. Apply speed and smoothing as before
        Vector3 targetVelocity = targetDirection * moveSpeed;
        _currentMoveVelocity = Vector3.SmoothDamp(_currentMoveVelocity, targetVelocity, ref _velocityDamper, _accelerationTime);
        
        // 4. Move the character
        _controller.Move(_currentMoveVelocity * Time.deltaTime);
    }
}
