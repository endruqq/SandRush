using UnityEngine;

public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly Transform _playerTransform;
    private readonly LayerMask _groundMask;

    /// <summary>
    /// The point on the ground the player is aiming at.
    /// </summary>
    public Vector3 GroundPosition { get; private set; }
    
    /// <summary>
    /// The actual point in space the weapon should aim at.
    /// </summary>
    public Vector3 AimPosition { get; private set; }

    /// <summary>
    /// How high above the ground cursor the actual aim point should be.
    /// </summary>
    private float _aimingHeight;

    public PlayerAiming(Camera cam, Transform playerTransform, LayerMask groundMask, float aimingHeight = 1.6f)
    {
        _cam = cam;
        _playerTransform = playerTransform;
        _groundMask = groundMask;
        _aimingHeight = aimingHeight;

        // Initialize with a fallback value.
        GroundPosition = _playerTransform.position + _playerTransform.forward * 5f;
        AimPosition = GroundPosition + Vector3.up * _aimingHeight;
    }

    public void Tick()
    {
        // 1. Create a ray from the camera through the mouse cursor.
        var ray = _cam.ScreenPointToRay(Input.mousePosition);

        // 2. Raycast against the ground layer.
        if (Physics.Raycast(ray, out var hitInfo, Mathf.Infinity, _groundMask))
        {
            GroundPosition = hitInfo.point;
        }
        else
        {
            // Fallback: If the raycast doesn't hit anything, project onto a mathematical plane at the player's feet.
            // This ensures aiming still works even when pointing the cursor off the map.
            var groundPlane = new Plane(Vector3.up, _playerTransform.position);
            if (groundPlane.Raycast(ray, out var enter))
            {
                GroundPosition = ray.GetPoint(enter);
            }
        }
        
        // 3. Calculate the final aiming position with the desired height.
        AimPosition = GroundPosition + (Vector3.up * _aimingHeight);
        
        // 4. For debugging purposes, draw lines in the scene view.
        Debug.DrawLine(_cam.transform.position, GroundPosition, Color.magenta); // From camera to ground point
        Debug.DrawLine(_playerTransform.position, AimPosition, Color.cyan); // From player to final aim point
    }
}
