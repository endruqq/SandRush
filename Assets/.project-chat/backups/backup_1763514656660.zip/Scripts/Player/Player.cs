using UnityEngine;
using Unity.Cinemachine;
using TMPro;

[RequireComponent(typeof(CharacterController))]
public class Player : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private Transform _firePoint;
    [SerializeField] private ParticleSystem _firePointParticles;
    [SerializeField] private GameObject _bulletPrefab;
    [SerializeField] private Animator _animator;
    [SerializeField] private TextMeshProUGUI _dashCooldownText;

    [Header("Movement Settings")]
    [SerializeField] private float moveSpeed = 3.5f;
    [SerializeField] private float accelerationTime = 0.1f;
    
    [Header("Animation Settings")]
    [SerializeField] private float animationSpeedMultiplier = 1f;
    [Tooltip("Lower values make turn animations smoother and less jerky.")]
    [SerializeField] private float animationTurnSpeedSmoothing = 15f;

    [Header("Aiming Settings")]
    [SerializeField] private LayerMask groundMask;
    [SerializeField] private GameObject _worldCursorPrefab;
    [Tooltip("Adjust this value until the character's model faces the exact direction of the shots.")]
    [SerializeField] private float _rotationOffset = 0f;
    [Tooltip("How quickly the character turns to face the aim direction.")]
    [SerializeField] private float _rotationSpeed = 25f;
    
    [Header("Impulse Sources")]
    [SerializeField] private CinemachineImpulseSource _dashImpulseSource;
    [SerializeField] private CinemachineImpulseSource _gunshotImpulseSource;
    
    private PlayerMovement _movement;
    private PlayerAiming _aiming;
    private PlayerShooting _shooting;
    private CharacterController _controller;
    private Quaternion _lastRotation;
    private float _turnSpeed;
    private WorldSpaceCursor _worldCursor;
    private Camera _mainCamera;

    private readonly int _moveXHash = Animator.StringToHash("MoveX");
    private readonly int _moveYHash = Animator.StringToHash("MoveY");
    private readonly int _speedHash = Animator.StringToHash("Speed");
    private readonly int _turnSpeedHash = Animator.StringToHash("TurnSpeed");

    [Range(25, 100)] public int CurrentHealth = 100;
    [Range(0, 10)] public int CurrentUltimate = 0;

    private static Player _instance;

    void Awake()
    {
        _controller = GetComponent<CharacterController>();
        _mainCamera = Camera.main;
        
        _aiming = new PlayerAiming(_mainCamera, _firePoint, groundMask);
        _movement = new PlayerMovement(_controller, _mainCamera.transform, accelerationTime);
        _shooting = new PlayerShooting(transform, _firePoint, _bulletPrefab, _firePointParticles);
        
        if (_dashCooldownText != null) _dashCooldownText.gameObject.SetActive(false);
        _lastRotation = transform.rotation;
        _instance = this;

        if (_worldCursorPrefab != null)
        {
            GameObject cursorInstance = Instantiate(_worldCursorPrefab);
            _worldCursor = cursorInstance.GetComponent<WorldSpaceCursor>();
        }
        Cursor.visible = false;
    }
    
    void Update()
    {
        _aiming.Tick();
        _movement.Tick(moveSpeed);

        if (_worldCursor != null)
        {
            _worldCursor.UpdatePosition(_aiming.GroundPosition);
        }

        UpdateAnimator();
        UpdateDashCooldownUI();
        if (_movement.JustDashed && _dashImpulseSource != null) 
            _dashImpulseSource.GenerateImpulse();
        if (Input.GetMouseButtonDown(0) && _gunshotImpulseSource != null) 
            _gunshotImpulseSource.GenerateImpulse();
    }

    void LateUpdate()
    {
        Vector3 lookDirection = _aiming.GroundPosition - transform.position;
        lookDirection.y = 0;

        if (lookDirection.sqrMagnitude > 0.01f)
        {
            Quaternion targetLookRotation = Quaternion.LookRotation(lookDirection);
            // FIXED: Corrected variable name case
            Quaternion finalRotation = targetLookRotation * Quaternion.Euler(0, _rotationOffset, 0);
            transform.rotation = Quaternion.Slerp(transform.rotation, finalRotation, Time.deltaTime * _rotationSpeed);
        }

        Vector3 P_Start = _firePoint.position;
        Vector3 P_Cel = _aiming.AimPosition;
        Vector3 shootDirection = P_Cel - P_Start;
        
        _shooting.Tick(shootDirection.normalized);

        CalculateTurnSpeed();
    }

    public static void TakeDamage(int amount)
    {
        _instance.CurrentHealth -= amount;
        _instance.CurrentHealth = Mathf.Clamp(_instance.CurrentHealth, 0, 100);
    }
    
    public static void GetUltimate(int amount)
    {
        _instance.CurrentUltimate += amount;
        _instance.CurrentUltimate = Mathf.Clamp(_instance.CurrentUltimate, 0, 10);
    }
    
    private void CalculateTurnSpeed()
    {
        Quaternion currentRotation = transform.rotation;
        Quaternion deltaRotation = currentRotation * Quaternion.Inverse(_lastRotation);
        deltaRotation.ToAngleAxis(out float angle, out Vector3 axis);

        if (float.IsNaN(axis.x)) return;

        float turnDirection = Mathf.Sign(axis.y);
        float turnAnglePerSecond = (angle * turnDirection) / Time.deltaTime;
        
        _turnSpeed = Mathf.Lerp(_turnSpeed, Mathf.Clamp(turnAnglePerSecond / 360f, -1f, 1f), Time.deltaTime * animationTurnSpeedSmoothing);
        _lastRotation = currentRotation;
    }

    private void UpdateAnimator()
    {
        if (_animator == null) return;

        float horizontalInput = Input.GetAxisRaw("Horizontal");
        float verticalInput = Input.GetAxisRaw("Vertical");

        Vector3 camForward = _mainCamera.transform.forward;
        camForward.y = 0;
        camForward.Normalize();
        Vector3 camRight = _mainCamera.transform.right;
        camRight.y = 0;
        camRight.Normalize();
        Vector3 worldMoveDirection = (camForward * verticalInput + camRight * horizontalInput).normalized;

        Vector3 localMoveDirection = transform.InverseTransformDirection(worldMoveDirection);

        float currentSpeed = new Vector3(_controller.velocity.x, 0, _controller.velocity.z).magnitude;
        float normalizedSpeed = (moveSpeed > 0.01f) ? currentSpeed / moveSpeed : 0f;
        
        _animator.SetFloat(_speedHash, normalizedSpeed * animationSpeedMultiplier);
        _animator.SetFloat(_turnSpeedHash, _turnSpeed);
        _animator.SetFloat(_moveXHash, localMoveDirection.x * normalizedSpeed);
        _animator.SetFloat(_moveYHash, localMoveDirection.z * normalizedSpeed);
    }
    
    private void UpdateDashCooldownUI()
    {
        if (_dashCooldownText == null) return;

        // FIXED: Corrected property name
        float cooldown = _movement.DashCooldownTimer;
        if (cooldown > 0)
        {
            _dashCooldownText.gameObject.SetActive(true);
            _dashCooldownText.text = cooldown.ToString("F1");
        }
        else
        {
            _dashCooldownText.gameObject.SetActive(false);
        }
    }
}
