using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class Player : MonoBehaviour
{
    // === INSPECTOR VARIABLES ===
    
    [Header("Dependencies")]
    [SerializeField] private Animator _animator;
    [SerializeField] private Transform _firePoint;
    [SerializeField] private GameObject _bulletPrefab;
    [SerializeField] private ParticleSystem _firePointParticles;

    [Header("Gameplay Stats")]
    [Range(0, 100)] public int CurrentHealth = 100;
    [Range(0, 10)] public int CurrentUltimate = 0;

    [Header("Movement Settings")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float accelerationTime = 0.1f;
    [Tooltip("How quickly the character rotates. Used for both movement and aiming-in-place.")]
    [SerializeField] private float rotationSpeed = 25f;

    [Header("Animation Settings")]
    [SerializeField] private float animationSpeedMultiplier = 1f;

    [Header("Aiming Settings")]
    [SerializeField] private LayerMask groundMask;
    [Tooltip("How much weight is given to the body vs. head when looking at the cursor.")]
    [Range(0f, 1f)]
    [SerializeField] private float lookAtBodyWeight = 0.7f;
    [Tooltip("The maximum angle (in degrees) the character's torso can twist left or right to aim while moving.")]
    [Range(0f, 180f)]
    [SerializeField] private float maxAimAngleWhileMoving = 110f;
    
    // === PRIVATE & STATIC VARIABLES ===
    
    private PlayerMovement _movement;
    private PlayerAiming _aiming;
    private PlayerShooting _shooting;
    private CharacterController _controller;
    private Camera _mainCamera;
    
    private readonly int _speedHash = Animator.StringToHash("Speed");
    private readonly int _moveXHash = Animator.StringToHash("MoveX");
    private readonly int _moveYHash = Animator.StringToHash("MoveY");
    
    private static Player _instance;

    // === UNITY METHODS ===

    void Awake()
    {
        _instance = this;
        _controller = GetComponent<CharacterController>();
        _mainCamera = Camera.main;
        
        _aiming = new PlayerAiming(_mainCamera, _firePoint, groundMask);
        _movement = new PlayerMovement(_controller, _mainCamera.transform, accelerationTime);
        _shooting = new PlayerShooting(transform, _firePoint, _bulletPrefab, _firePointParticles);
    }
    
    void Update()
    {
        _aiming.Tick();
        _movement.Tick(moveSpeed);
        
        UpdateCharacterRotation();
        UpdateAnimatorParameters();

        Vector3 shootDirection = (_aiming.AimPosition - _firePoint.position).normalized;
        _shooting.Tick(shootDirection);
    }
    
    private void OnAnimatorIK(int layerIndex)
    {
        if (_animator == null) return;

        Vector3 characterForward = transform.forward;
        Vector3 desiredAimDirection = (_aiming.AimPosition - transform.position).normalized;
        desiredAimDirection.y = 0;

        // While moving, we clamp the torso twist. When standing still, there's no clamp needed.
        bool isMoving = _controller.velocity.sqrMagnitude > 0.01f;
        float maxAngle = isMoving ? maxAimAngleWhileMoving : 360f; // Effectively no limit when standing still

        float angle = Vector3.SignedAngle(characterForward, desiredAimDirection, Vector3.up);
        float clampedAngle = Mathf.Clamp(angle, -maxAngle, maxAngle);

        Vector3 clampedDirection = Quaternion.Euler(0, clampedAngle, 0) * characterForward;
        Vector3 finalIkTargetPosition = transform.position + (clampedDirection * 10f);
        finalIkTargetPosition.y = _animator.GetBoneTransform(HumanBodyBones.Head).position.y;

        _animator.SetLookAtWeight(1f, lookAtBodyWeight, 1f, 1f, 0f);
        _animator.SetLookAtPosition(finalIkTargetPosition);
    }

    // === PUBLIC STATIC METHODS ===

    public static void TakeDamage(int amount)
    {
        if (_instance == null) return;
        _instance.CurrentHealth = Mathf.Clamp(_instance.CurrentHealth - amount, 0, 100);
        HealthUI.UpdateHealth(_instance.CurrentHealth);
    }
    
    public static void GetUltimate(int amount)
    {
        if (_instance == null) return;
        _instance.CurrentUltimate = Mathf.Clamp(_instance.CurrentUltimate + amount, 0, 10);
        UltimateUI.UpdateUltimate(_instance.CurrentUltimate);
    }

    // === HELPER METHODS ===

    private void UpdateCharacterRotation()
    {
        Vector3 horizontalVelocity = new Vector3(_controller.velocity.x, 0, _controller.velocity.z);
        
        Vector3 targetDirection;
        
        // --- THIS IS THE KEY LOGIC ---
        // If the player is moving (velocity is significant)
        if (horizontalVelocity.sqrMagnitude > 0.01f)
        {
            // The character should rotate to face the direction of movement.
            targetDirection = horizontalVelocity;
        }
        else // If the player is standing still
        {
            // The character should rotate to face the aiming direction.
            targetDirection = (_aiming.AimPosition - transform.position);
            targetDirection.y = 0; // Ensure it's a horizontal rotation
        }

        // Rotate the character towards the determined target direction
        if (targetDirection.sqrMagnitude > 0.01f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(targetDirection);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * rotationSpeed);
        }
    }
    
    private void UpdateAnimatorParameters()
    {
        if (_animator == null) return;
        
        Vector3 worldVelocity = new Vector3(_controller.velocity.x, 0, _controller.velocity.z);
        Vector3 localVelocity = transform.InverseTransformDirection(worldVelocity);
        Vector3 normalizedLocalVelocity = (moveSpeed > 0.01f) ? localVelocity / moveSpeed : Vector3.zero;
        float currentSpeed = normalizedLocalVelocity.magnitude;
        
        _animator.SetFloat(_speedHash, currentSpeed * animationSpeedMultiplier);
        _animator.SetFloat(_moveXHash, normalizedLocalVelocity.x);
        _animator.SetFloat(_moveYHash, normalizedLocalVelocity.z);
    }
}
