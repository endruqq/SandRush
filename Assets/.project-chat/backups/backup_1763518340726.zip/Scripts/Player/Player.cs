using UnityEngine;
using Unity.Cinemachine;
using TMPro;

[RequireComponent(typeof(CharacterController))]
public class Player : MonoBehaviour
{
    [Header("Dependencies")]
    [SerializeField] private Transform _firePoint;
    [SerializeField] private ParticleSystem _firePointParticles;
    [SerializeField] private GameObject _bulletPrefab;
    [SerializeField] private Animator _animator;
    [SerializeField] private TextMeshProUGUI _dashCooldownText;
    [SerializeField] private CinemachineImpulseSource _dashImpulseSource;
    [SerializeField] private CinemachineImpulseSource _gunshotImpulseSource;


    [Header("Movement Settings")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float accelerationTime = 0.1f;
    [Tooltip("How quickly the character turns to face the aim direction.")]
    [SerializeField] private float rotationSpeed = 35f;
    
    [Header("Animation Settings")]
    [SerializeField] private float animationSpeedMultiplier = 1f;

    [Header("Aiming Settings")]
    [SerializeField] private LayerMask groundMask;

    // --- Private & Static Variables ---
    private PlayerMovement _movement;
    private PlayerAiming _aiming;
    private PlayerShooting _shooting;
    private CharacterController _controller;
    private Camera _mainCamera;

    private readonly int _moveXHash = Animator.StringToHash("MoveX");
    private readonly int _moveYHash = Animator.StringToHash("MoveY");

    public int CurrentHealth { get; set; } = 100;
    public int CurrentUltimate { get; set; } = 0;
    private static Player _instance;

    void Awake()
    {
        _instance = this;
        _controller = GetComponent<CharacterController>();
        _mainCamera = Camera.main;
        
        _aiming = new PlayerAiming(_mainCamera, _firePoint, groundMask);
        // CORRECTED CONSTRUCTOR CALL
        _movement = new PlayerMovement(_controller, accelerationTime);
        _shooting = new PlayerShooting(transform, _firePoint, _bulletPrefab, _firePointParticles);
        
        if (_dashCooldownText != null) _dashCooldownText.gameObject.SetActive(false);
        Cursor.visible = false;
    }
    
    void Update()
    {
        float horizontalInput = Input.GetAxisRaw("Horizontal");
        float verticalInput = Input.GetAxisRaw("Vertical");

        _aiming.Tick();

        Vector3 aimDirection = _aiming.GroundPosition - transform.position;
        aimDirection.y = 0;
        aimDirection.Normalize();

        // CORRECTED TICK CALL
        _movement.Tick(moveSpeed, horizontalInput, verticalInput, aimDirection);

        UpdateCharacterRotation(aimDirection);
        UpdateAnimator(horizontalInput, verticalInput);
        UpdateDashCooldownUI(); // Restored call

        if (_movement.JustDashed && _dashImpulseSource != null) 
            _dashImpulseSource.GenerateImpulse();
        if (Input.GetMouseButtonDown(0) && _gunshotImpulseSource != null) 
            _gunshotImpulseSource.GenerateImpulse();
        
        _firePoint.LookAt(_aiming.AimPosition);
        Vector3 shootDirection = (_aiming.AimPosition - _firePoint.position).normalized;
        _shooting.Tick(shootDirection);
    }

    void UpdateCharacterRotation(Vector3 lookDirection)
    {
        if (lookDirection.sqrMagnitude > 0.01f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(lookDirection);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * rotationSpeed);
        }
    }

    void UpdateAnimator(float horizontalInput, float verticalInput)
    {
        if (_animator == null) return;
        
        _animator.SetFloat(_moveXHash, horizontalInput * animationSpeedMultiplier);
        _animator.SetFloat(_moveYHash, verticalInput * animationSpeedMultiplier);
    }

    private void UpdateDashCooldownUI()
    {
        if (_dashCooldownText == null) return;

        // CORRECTED PROPERTY NAME
        float cooldown = _movement.DashCooldownTimer;
        if (cooldown > 0)
        {
            _dashCooldownText.gameObject.SetActive(true);
            _dashCooldownText.text = cooldown.ToString("F1");
        }
        else
        {
            _dashCooldownText.gameObject.SetActive(false);
        }
    }
    
    public static void TakeDamage(int amount)
    {
        if (_instance == null) return;
        _instance.CurrentHealth = Mathf.Clamp(_instance.CurrentHealth - amount, 0, 100);
        HealthUI.UpdateHealth(_instance.CurrentHealth);
    }
    
    public static void GetUltimate(int amount)
    {
        if (_instance == null) return;
        _instance.CurrentUltimate = Mathf.Clamp(_instance.CurrentUltimate + amount, 0, 10);
        UltimateUI.UpdateUltimate(_instance.CurrentUltimate);
    }
}
