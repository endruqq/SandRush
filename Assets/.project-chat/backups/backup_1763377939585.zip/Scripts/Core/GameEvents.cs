using System;

public static class GameEvents
{
    // Zdarzenie, które będzie wywoływane za każdym razem, gdy wróg zginie.
    // Inne skrypty (jak Player) mogą go nasłuchiwać.
    public static event Action OnEnemyKilled;

    // Funkcja pomocnicza do wywoływania zdarzenia z dowolnego miejsca w kodzie.
    public static void ReportEnemyKilled()
    {
        OnEnemyKilled?.Invoke();
    }
}
