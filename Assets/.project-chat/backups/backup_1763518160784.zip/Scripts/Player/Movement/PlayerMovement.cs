using UnityEngine;

public class PlayerMovement
{
    private readonly float _accelerationTime;
    private readonly CharacterController _controller;

    // --- Dash Settings ---
    private readonly float _dashSpeed = 30f;
    private readonly float _dashDuration = 0.1f;
    private readonly float _dashCooldown = 1f;

    // --- State ---
    private Vector3 _currentMoveVelocity;
    private Vector3 _velocityDamper;
    private float _dashCooldownTimer;
    private float _dashTimer;
    private bool _isDashing;

    // --- Public State ---
    public bool JustDashed { get; private set; }
    public float DashCooldownTimer => _dashCooldownTimer;

    public PlayerMovement(CharacterController controller, float accelerationTime)
    {
        _controller = controller;
        _accelerationTime = accelerationTime;
    }

    public void Tick(float moveSpeed, float horizontalInput, float verticalInput, Vector3 aimForwardDirection)
    {
        JustDashed = false;
        
        Vector3 targetDirection;
        // Check if there is any movement input
        if (Mathf.Abs(horizontalInput) > 0.1f || Mathf.Abs(verticalInput) > 0.1f)
        {
            Vector3 aimRightDirection = new Vector3(aimForwardDirection.z, 0, -aimForwardDirection.x);
            targetDirection = (aimForwardDirection * verticalInput + aimRightDirection * horizontalInput).normalized;
        }
        else
        {
            targetDirection = Vector3.zero;
        }

        HandleDashState(targetDirection);

        if (_isDashing)
        {
            _controller.Move(targetDirection * _dashSpeed * Time.deltaTime);
            return;
        }

        Vector3 targetVelocity = targetDirection * moveSpeed;
        _currentMoveVelocity = Vector3.SmoothDamp(_currentMoveVelocity, targetVelocity, ref _velocityDamper, _accelerationTime);
        _controller.Move(_currentMoveVelocity * Time.deltaTime);
    }
    
    private void HandleDashState(Vector3 moveDirection)
    {
        if (_dashCooldownTimer > 0) _dashCooldownTimer -= Time.deltaTime;
        
        if (_dashTimer > 0)
        {
            _dashTimer -= Time.deltaTime;
            if (_dashTimer <= 0) _isDashing = false;
        }

        if (Input.GetKeyDown(KeyCode.Space) && _dashCooldownTimer <= 0 && moveDirection.sqrMagnitude > 0.1f)
        {
            JustDashed = true; 
            _isDashing = true;
            _dashCooldownTimer = _dashCooldown;
            _dashTimer = _dashDuration;
        }
    }
}
