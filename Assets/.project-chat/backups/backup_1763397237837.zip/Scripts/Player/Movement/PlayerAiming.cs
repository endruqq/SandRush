using UnityEngine;

public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly LayerMask _groundMask;

    public Vector3 AimPosition { get; private set; }

    public PlayerAiming(Camera cam, LayerMask groundMask)
    {
        _cam = cam;
        _groundMask = groundMask;

        if (_cam == null)
        {
            Debug.LogError("CRITICAL: Camera is not assigned to PlayerAiming script!");
        }
    }

    public void Tick()
    {
        if (_cam == null) return;

        Ray ray = _cam.ScreenPointToRay(Input.mousePosition);

        // --- VISUAL DEBUGGING ---
        // This will draw a long green line in the Scene view,
        // showing exactly where the aiming ray is going.
        Debug.DrawRay(ray.origin, ray.direction * 100f, Color.green);

        if (Physics.Raycast(ray, out RaycastHit hitInfo, Mathf.Infinity, _groundMask))
        {
            AimPosition = hitInfo.point;
        }
        else
        {
            // The log is no longer needed, the green line will show us the problem.
        }
    }
}
