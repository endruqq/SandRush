using UnityEngine;

// This script implements a controller-style aiming system.
// The cursor is always drawn at a fixed distance from the player,
// in the direction of the mouse. This method is foolproof and ignores all colliders/layers.
public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly Transform _playerTransform;
    private readonly float _cursorDistance;

    public Vector3 AimPosition { get; private set; }

    public PlayerAiming(Camera cam, Transform playerTransform, float cursorDistance)
    {
        _cam = cam;
        _playerTransform = playerTransform;
        _cursorDistance = cursorDistance;

        // Initialize with a fallback value in front of the player
        AimPosition = _playerTransform.position + _playerTransform.forward * _cursorDistance;
    }

    public void Tick()
    {
        // 1. Create a mathematical plane at the player's feet.
        var groundPlane = new Plane(Vector3.up, _playerTransform.position);

        // 2. Create a ray from the camera through the mouse cursor.
        var ray = _cam.ScreenPointToRay(Input.mousePosition);

        // 3. Find where the ray intersects the mathematical plane.
        if (groundPlane.Raycast(ray, out var enter))
        {
            // Get the 3D point of intersection.
            Vector3 mouseWorldPos = ray.GetPoint(enter);

            // 4. Calculate the direction from the player to that point.
            Vector3 direction = (mouseWorldPos - _playerTransform.position).normalized;

            // 5. The final AimPosition is a point on that direction vector,
            // at a fixed distance from the player.
            AimPosition = _playerTransform.position + direction * _cursorDistance;
        }
    }
}
