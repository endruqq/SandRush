using UnityEngine;

// Minimal dependencies for clarity, assuming other scripts like HealthUI exist.

[RequireComponent(typeof(CharacterController))]
public class Player : MonoBehaviour
{
    // === INSPECTOR VARIABLES ===
    
    [Header("Dependencies")]
    [SerializeField] private Animator _animator;
    [SerializeField] private Transform _firePoint;
    [SerializeField] private GameObject _bulletPrefab; // Restored dependency
    [SerializeField] private ParticleSystem _firePointParticles; // Restored dependency

    [Header("Gameplay Stats")]
    [Range(0, 100)] public int CurrentHealth = 100;
    [Range(0, 10)] public int CurrentUltimate = 0;

    [Header("Movement Settings")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float accelerationTime = 0.1f;
    [Tooltip("How quickly the character's model rotates to face the movement direction.")]
    [SerializeField] private float movementRotationSpeed = 25f;

    [Header("Animation Settings")]
    [SerializeField] private float animationSpeedMultiplier = 1f;

    [Header("Aiming Settings")]
    [SerializeField] private LayerMask groundMask;
    [Tooltip("How much weight is given to the body vs. head when looking at the cursor.")]
    [Range(0f, 1f)]
    [SerializeField] private float lookAtBodyWeight = 0.7f;
    [Tooltip("Limits the IK from creating unnatural poses. Increase this if the character bends weirdly at extreme angles.")]
    [Range(0f, 1f)]
    [SerializeField] private float ikClampWeight = 0.8f;
    
    // === PRIVATE & STATIC VARIABLES ===
    
    private PlayerMovement _movement;
    private PlayerAiming _aiming;
    private PlayerShooting _shooting; // Restored logic
    private CharacterController _controller;
    private Camera _mainCamera;
    
    // Restored all necessary animator parameter hashes
    private readonly int _speedHash = Animator.StringToHash("Speed");
    private readonly int _moveXHash = Animator.StringToHash("MoveX");
    private readonly int _moveYHash = Animator.StringToHash("MoveY");
    
    private static Player _instance;

    // === UNITY METHODS ===

    void Awake()
    {
        _instance = this;
        _controller = GetComponent<CharacterController>();
        _mainCamera = Camera.main;
        
        _aiming = new PlayerAiming(_mainCamera, _firePoint, groundMask);
        _movement = new PlayerMovement(_controller, _mainCamera.transform, accelerationTime);
        _shooting = new PlayerShooting(transform, _firePoint, _bulletPrefab, _firePointParticles); // Restored instantiation
    }
    
    void Update()
    {
        _aiming.Tick();
        _movement.Tick(moveSpeed);
        
        UpdateCharacterRotation();
        UpdateAnimatorParameters();

        // Restore shooting logic call
        Vector3 shootDirection = (_aiming.AimPosition - _firePoint.position).normalized;
        _shooting.Tick(shootDirection);
    }
    
    private void OnAnimatorIK(int layerIndex)
    {
        if (_animator == null) return;

        Vector3 originalAimPosition = _aiming.AimPosition;
        Vector3 headPosition = _animator.GetBoneTransform(HumanBodyBones.Head).position;
        Vector3 correctedAimPosition = new Vector3(originalAimPosition.x, headPosition.y, originalAimPosition.z);

        _animator.SetLookAtWeight(1f, lookAtBodyWeight, 1f, 1f, ikClampWeight);
        _animator.SetLookAtPosition(correctedAimPosition);
    }

    // === PUBLIC STATIC METHODS ===

    public static void TakeDamage(int amount)
    {
        if (_instance == null) return;
        _instance.CurrentHealth = Mathf.Clamp(_instance.CurrentHealth - amount, 0, 100);
        HealthUI.UpdateHealth(_instance.CurrentHealth);
    }
    
    public static void GetUltimate(int amount)
    {
        if (_instance == null) return;
        _instance.CurrentUltimate = Mathf.Clamp(_instance.CurrentUltimate + amount, 0, 10);
        UltimateUI.UpdateUltimate(_instance.CurrentUltimate);
    }

    // === HELPER METHODS ===

    private void UpdateCharacterRotation()
    {
        Vector3 horizontalVelocity = new Vector3(_controller.velocity.x, 0, _controller.velocity.z);
        if (horizontalVelocity.sqrMagnitude > 0.01f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(horizontalVelocity);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * movementRotationSpeed);
        }
    }
    
    private void UpdateAnimatorParameters()
    {
        if (_animator == null) return;

        // --- This logic correctly separates movement intention from character rotation ---
        
        // 1. Get world-space movement vector from the controller's velocity
        Vector3 worldVelocity = new Vector3(_controller.velocity.x, 0, _controller.velocity.z);

        // 2. Convert this world velocity into a local direction relative to the character's rotation
        Vector3 localVelocity = transform.InverseTransformDirection(worldVelocity);

        // 3. Normalize this local velocity vector to get values between -1 and 1 for MoveX/MoveY
        Vector3 normalizedLocalVelocity = (moveSpeed > 0.01f) ? localVelocity / moveSpeed : Vector3.zero;

        // 4. Calculate the overall speed as a single float (magnitude)
        float currentSpeed = normalizedLocalVelocity.magnitude;
        
        // 5. Send all parameters to the animator
        _animator.SetFloat(_speedHash, currentSpeed * animationSpeedMultiplier);
        _animator.SetFloat(_moveXHash, normalizedLocalVelocity.x);
        _animator.SetFloat(_moveYHash, normalizedLocalVelocity.z);
    }
}
