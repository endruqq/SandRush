using System;

// To jest jak globalna "tablica ogłoszeń".
public static class GameEvents
{
    // Ogłoszenie pod tytułem "Wróg Zginął".
    public static event Action OnEnemyKilled;

    // Funkcja do wywieszania ogłoszenia na tablicy.
    public static void ReportEnemyKilled()
    {
        OnEnemyKilled?.Invoke();
    }
}
