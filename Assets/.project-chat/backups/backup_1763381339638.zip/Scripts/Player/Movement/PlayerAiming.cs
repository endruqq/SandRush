using UnityEngine;

public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly Transform _firePoint;
    private readonly float _maxRayDistance = 100f;
    private readonly int _aimLayerMask;
    private readonly Transform _playerTransform; // Used for fallback plane

    public Vector3 AimPosition { get; private set; } // The point on the geometry we are aiming at
    public Vector3 ShootDirection { get; private set; } // The corrected horizontal direction for the bullet

    public PlayerAiming(Camera cam, Transform playerTransform, Transform firePoint)
    {
        _cam = cam;
        _playerTransform = playerTransform;
        _firePoint = firePoint;
        _aimLayerMask = ~LayerMask.GetMask("Player");

        // Initialize fallback values
        AimPosition = playerTransform.position + playerTransform.forward * 10f;
        ShootDirection = playerTransform.forward;
    }

    public void Tick()
    {
        Ray ray = _cam.ScreenPointToRay(Input.mousePosition);

        // Find the 3D point the player is aiming at
        if (Physics.Raycast(ray, out RaycastHit hit, _maxRayDistance, _aimLayerMask))
        {
            AimPosition = hit.point;
        }
        else
        {
            // Fallback if we don't hit anything: aim on the player's horizontal plane
            Plane groundPlane = new(Vector3.up, _playerTransform.position);
            if (groundPlane.Raycast(ray, out float enter))
            {
                AimPosition = ray.GetPoint(enter);
            }
        }
        
        // Calculate the corrected horizontal direction from the fire point to the aim position
        var direction = AimPosition - _firePoint.position;
        direction.y = 0;
        ShootDirection = direction.normalized;
    }
}
