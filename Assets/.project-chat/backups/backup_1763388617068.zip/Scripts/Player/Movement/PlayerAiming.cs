using UnityEngine;

public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly Transform _playerTransform;
    private readonly float _maxRayDistance = 100f;
    private readonly int _aimLayerMask;

    public Vector3 AimPosition { get; private set; }

    public PlayerAiming(Camera cam, Transform playerTransform)
    {
        _cam = cam;
        _playerTransform = playerTransform;
        _aimLayerMask = ~LayerMask.GetMask("Player");

        // Initialize fallback value
        AimPosition = _playerTransform.position + _playerTransform.forward * 10f;
    }

    public void Tick()
    {
        Ray ray = _cam.ScreenPointToRay(Input.mousePosition);

        // Find the 3D point the player is aiming at using a raycast
        if (Physics.Raycast(ray, out RaycastHit hit, _maxRayDistance, _aimLayerMask))
        {
            AimPosition = hit.point;
        }
        else
        {
            // Fallback if the ray doesn't hit any colliders
            // Cast onto a virtual plane at the player's height
            Plane groundPlane = new(Vector3.up, _playerTransform.position);
            if (groundPlane.Raycast(ray, out float enter))
            {
                AimPosition = ray.GetPoint(enter);
            }
            else
            {
                // Last resort if even the plane cast fails
                AimPosition = ray.GetPoint(50f);
            }
        }
    }
}
