using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class EnemyAI : MonoBehaviour
{
    public enum AttackType { Ranged, Melee, Exploder }
    
    [Header("AI Behavior")]
    [Tooltip("Wybierz, czy wróg atakuje z dystansu, w zwarciu, czy wybucha.")]
    [SerializeField] private AttackType _attackType = AttackType.Ranged;
    
    [Header("Dependencies")]
    [Tooltip("Obiekt gracza, który ma być śledzony.")]
    [SerializeField] private Transform _playerTransform;

    [Header("AI Stats")]
    [Tooltip("Jak daleko wróg 'widzi' gracza.")]
    [SerializeField] private float _detectionRadius = 15f;
    [Tooltip("Jak blisko wróg musi podejść, aby zaatakować/wybuchnąć.")]
    [SerializeField] private float _attackRange = 10f;
    [Tooltip("Częstotliwość ataków (dla Ranged i Melee).")]
    [SerializeField] private float _attackRate = 1f;

    [Header("Ranged Weapon Settings")]
    [SerializeField] private GameObject _bulletPrefab;
    [SerializeField] private Transform _firePoint;
    [SerializeField] private float _bulletSpeed = 20f;
    
    [Header("Melee Settings")]
    [SerializeField] private int _meleeDamage = 10;
    
    [Header("Exploder Settings")]
    [SerializeField] private int _explosionDamage = 50;
    [SerializeField] private float _explosionRadius = 5f;
    [Tooltip("Czas w sekundach od zatrzymania się do wybuchu.")]
    [SerializeField] private float _explosionFuseTime = 1.5f;
    [Tooltip("Efekt cząsteczkowy, który pojawi się podczas eksplozji.")]
    [SerializeField] private GameObject _explosionVFX;

    private enum State { Idle, Chasing, Attacking }
    private State _currentState;
    private NavMeshAgent _navAgent;
    
    private float _distanceToPlayer;
    private float _nextAttackTime;
    private float _fuseTimer;

    void Awake()
    {
        _navAgent = GetComponent<NavMeshAgent>();
        if (_playerTransform == null)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if(player != null) _playerTransform = player.transform;
        }
    }

    void Start()
    {
        _currentState = State.Idle;
    }

    void Update()
    {
        if (_playerTransform == null)
        {
            if(_navAgent.isOnNavMesh) _navAgent.isStopped = true;
            return;
        }

        _distanceToPlayer = Vector3.Distance(transform.position, _playerTransform.position);

        switch (_currentState)
        {
            case State.Idle: HandleIdleState(); break;
            case State.Chasing: HandleChasingState(); break;
            case State.Attacking: HandleAttackingState(); break;
        }
    }

    private void HandleIdleState()
    {
        if (_distanceToPlayer <= _detectionRadius) _currentState = State.Chasing;
    }

    private void HandleChasingState()
    {
        _navAgent.isStopped = false;
        _navAgent.SetDestination(_playerTransform.position);

        if (_distanceToPlayer <= _attackRange)
        {
            _currentState = State.Attacking;
            if (_attackType == AttackType.Exploder) _fuseTimer = _explosionFuseTime;
        }
        else if (_distanceToPlayer > _detectionRadius)
        {
            _currentState = State.Idle;
            _navAgent.isStopped = true;
        }
    }

    private void HandleAttackingState()
    {
        _navAgent.isStopped = true;
        
        Vector3 lookDirection = (_playerTransform.position - transform.position).normalized;
        lookDirection.y = 0;
        transform.rotation = Quaternion.LookRotation(lookDirection);

        if (_attackType == AttackType.Exploder)
        {
            _fuseTimer -= Time.deltaTime;
            if (_fuseTimer <= 0f) Explode();
        }
        else
        {
            if (Time.time >= _nextAttackTime)
            {
                if (_attackType == AttackType.Ranged) PerformRangedAttack();
                else PerformMeleeAttack();
                _nextAttackTime = Time.time + 1f / _attackRate;
            }

            if (_distanceToPlayer > _attackRange) _currentState = State.Chasing;
        }
    }

    private void PerformRangedAttack()
    {
        if (_bulletPrefab == null || _firePoint == null || _playerTransform == null) return;

        GameObject bulletGO = Instantiate(_bulletPrefab, _firePoint.position, _firePoint.rotation);
        Bullet bullet = bulletGO.GetComponent<Bullet>();
        if (bullet != null)
        {
            Vector3 shootDirection = _playerTransform.position - _firePoint.position;
            shootDirection.y = 0;
            bullet.Fire(shootDirection.normalized, _bulletSpeed);
        }
    }

    private void PerformMeleeAttack()
    {
        if (_distanceToPlayer <= _attackRange && _playerTransform.TryGetComponent<Health>(out Health playerHealth))
        {
            playerHealth.TakeDamage(_meleeDamage);
        }
    }

    private void Explode()
    {
        if (_explosionVFX != null) 
        {
            Instantiate(_explosionVFX, transform.position, Quaternion.identity);
        }
        
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, _explosionRadius);
        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.TryGetComponent<Health>(out Health health))
            {
                health.TakeDamage(_explosionDamage);
            }
        }
        
        Destroy(gameObject);
    }
    
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, _detectionRadius);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, _attackRange);
        if (_attackType == AttackType.Exploder)
        {
            Gizmos.color = Color.magenta;
            Gizmos.DrawWireSphere(transform.position, _explosionRadius);
        }
    }
}
