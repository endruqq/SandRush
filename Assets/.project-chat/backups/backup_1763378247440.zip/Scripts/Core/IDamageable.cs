// Ten interfejs definiuje "kontrakt" dla wszystkiego, co może otrzymywać obrażenia.
public interface IDamageable
{
    void TakeDamage(float amount);
}
