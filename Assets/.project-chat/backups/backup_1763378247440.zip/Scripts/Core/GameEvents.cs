using System;

// Ten skrypt nie jest komponentem, to globalna klasa dostępna z każdego miejsca.
public static class GameEvents
{
    // Zdarzenie ogłaszane, gdy wróg ginie.
    public static event Action OnEnemyKilled;

    // Każdy skrypt (np. EnemyManager) może wywołać tę metodę, aby ogłosić zdarzenie.
    public static void ReportEnemyKilled()
    {
        OnEnemyKilled?.Invoke();
    }
}
