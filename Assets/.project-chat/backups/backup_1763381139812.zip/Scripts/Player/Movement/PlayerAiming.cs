using UnityEngine;

public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly Transform _playerTransform; // Keeping for fallback plane
    private readonly float _maxRayDistance = 100f;
    private readonly int _aimLayerMask;

    public Vector3 AimPosition { get; private set; }

    public PlayerAiming(Camera cam, Transform playerTransform)
    {
        _cam = cam;
        _playerTransform = playerTransform;
        // It's a good practice to put the player on a "Player" layer and ignore it for aiming rays
        _aimLayerMask = ~LayerMask.GetMask("Player");
    }

    public void Tick()
    {
        Ray ray = _cam.ScreenPointToRay(Input.mousePosition);

        if (Physics.Raycast(ray, out RaycastHit hit, _maxRayDistance, _aimLayerMask))
        {
            AimPosition = hit.point;
        }
        else
        {
            // Fallback for when the ray doesn't hit anything in the scene
            Plane groundPlane = new(Vector3.up, _playerTransform.position);
            if (groundPlane.Raycast(ray, out float enter))
            {
                AimPosition = ray.GetPoint(enter);
            }
            else
            {
                // Last resort fallback
                AimPosition = ray.GetPoint(50f);
            }
        }
    }
}
