using UnityEngine;
using Unity.Cinemachine;
using TMPro;

[RequireComponent(typeof(CharacterController))]
public class Player : MonoBehaviour
{
    // === INSPECTOR VARIABLES ===
    
    [Header("Dependencies")]
    [SerializeField] private Animator _animator;
    [SerializeField] private Transform _firePoint;
    
    [Header("Movement Settings")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float accelerationTime = 0.1f;
    [Tooltip("How quickly the character's model rotates to face the movement direction.")]
    [SerializeField] private float movementRotationSpeed = 25f;

    [Header("Animation Settings")]
    [SerializeField] private float animationSpeedMultiplier = 1f;

    [Header("Aiming Settings")]
    [SerializeField] private LayerMask groundMask;
    [Tooltip("How much weight is given to the body vs. head when looking at the cursor.")]
    [Range(0f, 1f)]
    [SerializeField] private float lookAtBodyWeight = 0.7f;
    
    // === PRIVATE VARIABLES ===
    
    private PlayerMovement _movement;
    private PlayerAiming _aiming;
    private CharacterController _controller;
    private Camera _mainCamera;
    
    private readonly int _speedHash = Animator.StringToHash("Speed");

    // === UNITY METHODS ===

    void Awake()
    {
        _controller = GetComponent<CharacterController>();
        _mainCamera = Camera.main;
        
        _aiming = new PlayerAiming(_mainCamera, _firePoint, groundMask);
        _movement = new PlayerMovement(_controller, _mainCamera.transform, accelerationTime);
    }
    
    void Update()
    {
        // --- LOGIC TICKS ---
        _aiming.Tick();
        _movement.Tick(moveSpeed);
        
        // --- ACTIONS ---
        UpdateCharacterRotation();
        UpdateAnimatorParameters();
    }

    // This special Unity function is called after the Animator has calculated its animations for the frame.
    // It's the perfect place to override bone rotations for things like aiming (IK - Inverse Kinematics).
    private void OnAnimatorIK(int layerIndex)
    {
        if (_animator == null) return;
        
        // We set the weights for how much the body, head, and eyes should try to look at the target.
        _animator.SetLookAtWeight(1f, lookAtBodyWeight, 1f, 1f, 0.5f);
        
        // The target position for the look is the aiming position calculated by our aiming script.
        _animator.SetLookAtPosition(_aiming.AimPosition);
    }

    // === HELPER METHODS ===

    private void UpdateCharacterRotation()
    {
        // Get the character's horizontal velocity.
        Vector3 horizontalVelocity = new Vector3(_controller.velocity.x, 0, _controller.velocity.z);

        // If the character is moving, rotate them to face the direction of movement.
        if (horizontalVelocity.sqrMagnitude > 0.01f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(horizontalVelocity);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * movementRotationSpeed);
        }
    }
    
    private void UpdateAnimatorParameters()
    {
        if (_animator == null) return;

        // Calculate the character's speed.
        float currentSpeed = new Vector3(_controller.velocity.x, 0, _controller.velocity.z).magnitude;
        
        // Normalize the speed to a 0-1 range.
        float normalizedSpeed = (moveSpeed > 0.01f) ? currentSpeed / moveSpeed : 0f;
        
        // Send the speed to the animator. The Blend Tree for movement now only needs one parameter!
        _animator.SetFloat(_speedHash, normalizedSpeed * animationSpeedMultiplier);
    }
    
    // --- LEGACY/UNUSED CODE (for reference, can be removed) ---
    // The following methods and variables are no longer needed with this new system.
    // We don't need to calculate turn speed or pass MoveX/MoveY to the animator anymore.
    
    // private readonly int _moveXHash = Animator.StringToHash("MoveX");
    // private readonly int _moveYHash = Animator.StringToHash("MoveY");
    // private readonly int _turnSpeedHash = Animator.StringToHash("TurnSpeed");
    // [SerializeField] private float animationTurnSpeedSmoothing = 15f;
    // private float _turnSpeed;
    // private Quaternion _lastRotation;
}
