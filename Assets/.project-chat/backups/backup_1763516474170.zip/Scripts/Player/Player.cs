using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class Player : MonoBehaviour
{
    // === INSPECTOR VARIABLES ===
    
    [Header("Dependencies")]
    [SerializeField] private Animator _animator;
    [SerializeField] private Transform _firePoint;
    [SerializeField] private GameObject _bulletPrefab;
    [SerializeField] private ParticleSystem _firePointParticles;

    [Header("Gameplay Stats")]
    [Range(0, 100)] public int CurrentHealth = 100;
    [Range(0, 10)] public int CurrentUltimate = 0;

    [Header("Movement Settings")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float accelerationTime = 0.1f;
    [Tooltip("How quickly the character's model rotates to face the movement direction.")]
    [SerializeField] private float movementRotationSpeed = 25f;

    [Header("Animation Settings")]
    [SerializeField] private float animationSpeedMultiplier = 1f;

    [Header("Aiming Settings")]
    [SerializeField] private LayerMask groundMask;
    [Tooltip("How much weight is given to the body vs. head when looking at the cursor.")]
    [Range(0f, 1f)]
    [SerializeField] private float lookAtBodyWeight = 0.7f;
    [Tooltip("The maximum angle (in degrees) the character's torso can twist left or right to aim.")]
    [Range(0f, 180f)]
    [SerializeField] private float maxAimAngle = 110f;
    
    // === PRIVATE & STATIC VARIABLES ===
    
    private PlayerMovement _movement;
    private PlayerAiming _aiming;
    private PlayerShooting _shooting;
    private CharacterController _controller;
    private Camera _mainCamera;
    
    private readonly int _speedHash = Animator.StringToHash("Speed");
    private readonly int _moveXHash = Animator.StringToHash("MoveX");
    private readonly int _moveYHash = Animator.StringToHash("MoveY");
    
    private static Player _instance;

    // === UNITY METHODS ===

    void Awake()
    {
        _instance = this;
        _controller = GetComponent<CharacterController>();
        _mainCamera = Camera.main;
        
        _aiming = new PlayerAiming(_mainCamera, _firePoint, groundMask);
        _movement = new PlayerMovement(_controller, _mainCamera.transform, accelerationTime);
        _shooting = new PlayerShooting(transform, _firePoint, _bulletPrefab, _firePointParticles);
    }
    
    void Update()
    {
        _aiming.Tick();
        _movement.Tick(moveSpeed);
        
        UpdateCharacterRotation();
        UpdateAnimatorParameters();

        Vector3 shootDirection = (_aiming.AimPosition - _firePoint.position).normalized;
        _shooting.Tick(shootDirection);
    }
    
    private void OnAnimatorIK(int layerIndex)
    {
        if (_animator == null) return;

        // --- NEW AIMING LOGIC WITH ANGLE CLAMPING ---

        // 1. Define the character's forward direction (where the legs are pointing)
        Vector3 characterForward = transform.forward;
        
        // 2. Define the desired aiming direction (from character to cursor)
        Vector3 desiredAimDirection = (_aiming.AimPosition - transform.position).normalized;
        desiredAimDirection.y = 0; // Flatten the vector for horizontal angle calculation

        // 3. Calculate the angle between where the character is running and where they want to aim
        float angle = Vector3.SignedAngle(characterForward, desiredAimDirection, Vector3.up);

        // 4. Clamp this angle to the maximum allowed twist
        float clampedAngle = Mathf.Clamp(angle, -maxAimAngle, maxAimAngle);

        // 5. Create a new, clamped direction vector by rotating the character's forward vector by the clamped angle
        Vector3 clampedDirection = Quaternion.Euler(0, clampedAngle, 0) * characterForward;
        
        // 6. Generate the final IK target position based on this safe, clamped direction
        Vector3 finalIkTargetPosition = transform.position + (clampedDirection * 10f); // Project 10 units away
        finalIkTargetPosition.y = _animator.GetBoneTransform(HumanBodyBones.Head).position.y; // Ensure it's at head height

        // 7. Apply the IK using this safe target. We no longer need ikClampWeight.
        _animator.SetLookAtWeight(1f, lookAtBodyWeight, 1f, 1f, 0f); // clampWeight is now 0
        _animator.SetLookAtPosition(finalIkTargetPosition);
    }

    // === PUBLIC STATIC METHODS ===

    public static void TakeDamage(int amount)
    {
        if (_instance == null) return;
        _instance.CurrentHealth = Mathf.Clamp(_instance.CurrentHealth - amount, 0, 100);
        HealthUI.UpdateHealth(_instance.CurrentHealth);
    }
    
    public static void GetUltimate(int amount)
    {
        if (_instance == null) return;
        _instance.CurrentUltimate = Mathf.Clamp(_instance.CurrentUltimate + amount, 0, 10);
        UltimateUI.UpdateUltimate(_instance.CurrentUltimate);
    }

    // === HELPER METHODS ===

    private void UpdateCharacterRotation()
    {
        Vector3 horizontalVelocity = new Vector3(_controller.velocity.x, 0, _controller.velocity.z);
        if (horizontalVelocity.sqrMagnitude > 0.01f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(horizontalVelocity);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * movementRotationSpeed);
        }
    }
    
    private void UpdateAnimatorParameters()
    {
        if (_animator == null) return;
        
        Vector3 worldVelocity = new Vector3(_controller.velocity.x, 0, _controller.velocity.z);
        Vector3 localVelocity = transform.InverseTransformDirection(worldVelocity);
        Vector3 normalizedLocalVelocity = (moveSpeed > 0.01f) ? localVelocity / moveSpeed : Vector3.zero;
        float currentSpeed = normalizedLocalVelocity.magnitude;
        
        _animator.SetFloat(_speedHash, currentSpeed * animationSpeedMultiplier);
        _animator.SetFloat(_moveXHash, normalizedLocalVelocity.x);
        _animator.SetFloat(_moveYHash, normalizedLocalVelocity.z);
    }
}
