using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Bullet : MonoBehaviour
{
    [Header("Bullet Stats")]
    [SerializeField] private float damage = 25f;
    [SerializeField] private GameObject _hitEffectPrefab;

    private Rigidbody _rb;
    private ObjectPool<Bullet> _pool;
    private readonly float _lifetime = 3f;
    private float _timer;

    private void Awake()
    {
        _rb = GetComponent<Rigidbody>();
    }

    public void Init(ObjectPool<Bullet> pool)
    {
        _pool = pool;
    }

    public void Fire(Vector3 dir, float speed)
    {
        _timer = _lifetime;
        if(_rb != null) 
        {
            _rb.linearVelocity = dir * speed;
        }
    }

    void Update()
    {
        _timer -= Time.deltaTime;
        if (_timer <= 0 && _pool != null)
        {
            _pool.ReturnObject(this);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        // --- UPROSZCZONA I POPRAWNA LOGIKA ---
        
        // 1. Spróbuj zadać obrażenia trafionemu obiektowi
        if (collision.collider.TryGetComponent<Health>(out var health))
        {
            health.TakeDamage(damage);
        }
        
        // 2. Stwórz efekt trafienia
        if (_hitEffectPrefab != null)
        {
            ContactPoint contact = collision.contacts[0];
            Quaternion rot = Quaternion.LookRotation(contact.normal);
            GameObject hitFx = Instantiate(_hitEffectPrefab, contact.point, rot);
            Destroy(hitFx, 1f);
        }

        // 3. Zwróć pocisk do puli (jeśli jej używa)
        if (_pool != null)
        {
            _pool.ReturnObject(this);
        }
        else
        {
            Destroy(gameObject); // Na wypadek, gdyby pocisk nie był z puli (np. pocisk wroga)
        }
    }
}
