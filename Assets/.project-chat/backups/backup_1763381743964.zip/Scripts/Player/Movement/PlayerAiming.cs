using UnityEngine;

public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly Transform _playerTransform; 
    private readonly float _maxRayDistance = 100f;
    private readonly int _aimLayerMask;

    // The precise point in 3D space the player is aiming at. Used for character rotation.
    public Vector3 AimPosition { get; private set; }

    // The visually corrected direction for shooting, aligned with the camera's perspective.
    public Vector3 ShootDirection { get; private set; }

    public PlayerAiming(Camera cam, Transform playerTransform)
    {
        _cam = cam;
        _playerTransform = playerTransform;
        _aimLayerMask = ~LayerMask.GetMask("Player");

        // Initialize fallback values
        AimPosition = _playerTransform.position + _playerTransform.forward * 10f;
        ShootDirection = _playerTransform.forward;
    }

    public void Tick()
    {
        Ray ray = _cam.ScreenPointToRay(Input.mousePosition);

        // --- Visually Corrected Shooting Direction ---
        // This is the core of the "Synthetik" style aiming.
        // We take the camera's view direction, flatten it, and use it for the bullet.
        // This ensures the bullet's trajectory on screen perfectly matches the player's line of sight.
        Vector3 shootDirection = ray.direction;
        shootDirection.y = 0;
        ShootDirection = shootDirection.normalized;


        // --- 3D Aim Position for Character Rotation ---
        // We still need the actual 3D point for rotating the character model correctly.
        if (Physics.Raycast(ray, out RaycastHit hit, _maxRayDistance, _aimLayerMask))
        {
            AimPosition = hit.point;
        }
        else
        {
            // Fallback: aim on the player's horizontal plane if the ray hits nothing.
            Plane groundPlane = new(Vector3.up, _playerTransform.position);
            if (groundPlane.Raycast(ray, out float enter))
            {
                AimPosition = ray.GetPoint(enter);
            }
        }
    }
}
