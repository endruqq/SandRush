using UnityEngine;
using Unity.Cinemachine;
using TMPro;

[RequireComponent(typeof(CharacterController))]
public class Player : MonoBehaviour
{
    // === INSPECTOR VARIABLES ===
    
    [Header("Dependencies")]
    [SerializeField] private Animator _animator;
    [SerializeField] private Transform _firePoint;
    
    [Header("Gameplay Stats")]
    [Range(0, 100)] public int CurrentHealth = 100;
    [Range(0, 10)] public int CurrentUltimate = 0;

    [Header("Movement Settings")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float accelerationTime = 0.1f;
    [Tooltip("How quickly the character's model rotates to face the movement direction.")]
    [SerializeField] private float movementRotationSpeed = 25f;

    [Header("Animation Settings")]
    [SerializeField] private float animationSpeedMultiplier = 1f;

    [Header("Aiming Settings")]
    [SerializeField] private LayerMask groundMask;
    [Tooltip("How much weight is given to the body vs. head when looking at the cursor.")]
    [Range(0f, 1f)]
    [SerializeField] private float lookAtBodyWeight = 0.7f;
    [Tooltip("Limits the IK from creating unnatural poses. Increase this if the character bends weirdly at extreme angles.")]
    [Range(0f, 1f)]
    [SerializeField] private float ikClampWeight = 0.8f;
    
    // === PRIVATE & STATIC VARIABLES ===
    
    private PlayerMovement _movement;
    private PlayerAiming _aiming;
    private CharacterController _controller;
    private Camera _mainCamera;
    
    private readonly int _speedHash = Animator.StringToHash("Speed");
    
    private static Player _instance;

    // === UNITY METHODS ===

    void Awake()
    {
        _instance = this; // Set up the singleton instance
        _controller = GetComponent<CharacterController>();
        _mainCamera = Camera.main;
        
        _aiming = new PlayerAiming(_mainCamera, _firePoint, groundMask);
        _movement = new PlayerMovement(_controller, _mainCamera.transform, accelerationTime);
    }
    
    void Update()
    {
        _aiming.Tick();
        _movement.Tick(moveSpeed);
        
        UpdateCharacterRotation();
        UpdateAnimatorParameters();
    }
    
    private void OnAnimatorIK(int layerIndex)
    {
        if (_animator == null) return;

        Vector3 originalAimPosition = _aiming.AimPosition;
        Vector3 headPosition = _animator.GetBoneTransform(HumanBodyBones.Head).position;
        Vector3 correctedAimPosition = new Vector3(originalAimPosition.x, headPosition.y, originalAimPosition.z);

        // Use the new ikClampWeight variable from the Inspector in the 5th parameter
        _animator.SetLookAtWeight(1f, lookAtBodyWeight, 1f, 1f, ikClampWeight);
        _animator.SetLookAtPosition(correctedAimPosition);
    }

    // === PUBLIC STATIC METHODS (for external scripts) ===

    public static void TakeDamage(int amount)
    {
        if (_instance == null) return;
        
        _instance.CurrentHealth -= amount;
        _instance.CurrentHealth = Mathf.Clamp(_instance.CurrentHealth, 0, 100);
        HealthUI.UpdateHealth(_instance.CurrentHealth);
    }
    
    public static void GetUltimate(int amount)
    {
        if (_instance == null) return;

        _instance.CurrentUltimate += amount;
        _instance.CurrentUltimate = Mathf.Clamp(_instance.CurrentUltimate, 0, 10);
        UltimateUI.UpdateUltimate(_instance.CurrentUltimate);
    }

    // === HELPER METHODS ===

    private void UpdateCharacterRotation()
    {
        Vector3 horizontalVelocity = new Vector3(_controller.velocity.x, 0, _controller.velocity.z);

        if (horizontalVelocity.sqrMagnitude > 0.01f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(horizontalVelocity);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * movementRotationSpeed);
        }
    }
    
    private void UpdateAnimatorParameters()
    {
        if (_animator == null) return;

        float currentSpeed = new Vector3(_controller.velocity.x, 0, _controller.velocity.z).magnitude;
        float normalizedSpeed = (moveSpeed > 0.01f) ? currentSpeed / moveSpeed : 0f;
        
        _animator.SetFloat(_speedHash, normalizedSpeed * animationSpeedMultiplier);
    }
}
