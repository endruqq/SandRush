using UnityEngine;

public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly Transform _playerTransform;
    private readonly LayerMask _groundMask;
    private readonly float _aimingHeight;

    /// <summary>
    /// The point on the ground, directly below the AimPosition. This is where the cursor indicator should be.
    /// </summary>
    public Vector3 GroundPosition { get; private set; }

    /// <summary>
    /// The actual point in space the weapon aims at, located on a plane at a fixed height.
    /// </summary>
    public Vector3 AimPosition { get; private set; }

    public PlayerAiming(Camera cam, Transform playerTransform, LayerMask groundMask, float aimingHeight)
    {
        _cam = cam;
        _playerTransform = playerTransform;
        _groundMask = groundMask;
        _aimingHeight = aimingHeight;

        // Initialize with fallback values
        AimPosition = _playerTransform.position + Vector3.up * _aimingHeight + _playerTransform.forward * 5f;
        GroundPosition = new Vector3(AimPosition.x, _playerTransform.position.y, AimPosition.z);
    }

    public void Tick()
    {
        // 1. Create an infinite mathematical plane at the desired aiming height, relative to the player's position.
        // This is the plane the player is directly aiming on.
        var aimingPlane = new Plane(Vector3.up, _playerTransform.position + Vector3.up * _aimingHeight);

        // 2. Create a ray from the camera through the mouse cursor.
        var ray = _cam.ScreenPointToRay(Input.mousePosition);

        // 3. Find the intersection point with the aiming plane. This is our main target.
        if (aimingPlane.Raycast(ray, out var enter))
        {
            AimPosition = ray.GetPoint(enter);
        }

        // 4. Find the corresponding ground position by casting a ray downwards from the aim target.
        // This is for the cursor indicator and for player rotation.
        if (Physics.Raycast(AimPosition, Vector3.down, out var hitInfo, Mathf.Infinity, _groundMask))
        {
            GroundPosition = hitInfo.point;
        }
        else
        {
            // Fallback if there is no ground below the cursor (e.g., aiming over a cliff)
            GroundPosition = new Vector3(AimPosition.x, _playerTransform.position.y, AimPosition.z);
        }
        
        // 5. Debug lines to visualize the logic exactly like in your reference image.
        // Red line from player's weapon to the aim target in the air
        Debug.DrawLine(_playerTransform.position, AimPosition, Color.red); 
        // White line from the aim target down to the ground indicator
        Debug.DrawLine(AimPosition, GroundPosition, Color.white); 
    }
}
