using UnityEngine;

public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly LayerMask _groundMask;

    public Vector3 AimPosition { get; private set; }

    public PlayerAiming(Camera cam, LayerMask groundMask)
    {
        _cam = cam;
        _groundMask = groundMask;
    }

    public void Tick()
    {
        Ray ray = _cam.ScreenPointToRay(Input.mousePosition);

        if (Physics.Raycast(ray, out RaycastHit hitInfo, Mathf.Infinity, _groundMask))
        {
            AimPosition = hitInfo.point;
        }
        else
        {
            // If we are here, it means the raycast is failing.
            Debug.Log("CURSOR BLOCKED: Raycast did not hit anything on the 'Ground' layer.");
        }
    }
}
