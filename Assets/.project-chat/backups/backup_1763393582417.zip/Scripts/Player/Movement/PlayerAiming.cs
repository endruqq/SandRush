using UnityEngine;

// This script implements the logic provided by the user.
// Its only job is to find the point on the ground plane where the user is aiming.
public class PlayerAiming
{
    private readonly Camera _cam;
    private readonly LayerMask _groundMask;

    public Vector3 AimPosition { get; private set; }

    public PlayerAiming(Camera cam, LayerMask groundMask)
    {
        _cam = cam;
        _groundMask = groundMask;
    }

    public void Tick()
    {
        // Create a ray from the camera passing through the mouse cursor.
        Ray ray = _cam.ScreenPointToRay(Input.mousePosition);

        // Perform a raycast ONLY against the ground layer.
        if (Physics.Raycast(ray, out RaycastHit hitInfo, Mathf.Infinity, _groundMask))
        {
            // The raycast hit the ground, this is our aim position.
            AimPosition = hitInfo.point;
        }
        // If the raycast doesn't hit the ground, we don't update the aim position.
        // It will retain its last valid value.
    }
}
